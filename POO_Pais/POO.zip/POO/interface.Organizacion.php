
<?php
interface Organizacion {
  public function imprimirONG();
}

?>